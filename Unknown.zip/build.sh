#!/bin/bash
set -e
make clean
make
mkdir -p out
find .theos -name "GustavoPanel.dylib" -exec cp {} out/ \;
echo "[+] dylib em out/GustavoPanel.dylib"
