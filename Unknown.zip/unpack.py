#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
unpack.py - recria o projeto GustavoPanel a partir do arquivo de texto unico.
uso:  python3 unpack.py GustavoPanel.txt
"""
import os, sys

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    src = open(sys.argv[1], "r", encoding="utf-8").read().splitlines()
    out = os.path.join(os.getcwd(), "GustavoPanel")
    cur, buf, n = None, [], 0

    def flush():
        nonlocal n
        if cur is None: return
        full = os.path.join(out, cur)
        d = os.path.dirname(full)
        if d: os.makedirs(d, exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write("\n".join(buf).rstrip("\n") + "\n")
        n += 1
        print("[+]", cur)

    for line in src:
        if line.startswith("===== FILE:") and line.rstrip().endswith("====="):
            flush()
            cur = line[len("===== FILE:"):].rstrip().rstrip("=").strip()
            buf = []
        elif cur is not None:
            buf.append(line)
    flush()
    print("[+] %d arquivos em %s" % (n, out))

if __name__ == "__main__":
    main()
