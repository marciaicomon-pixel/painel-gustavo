//
//  GustavoPanel - entry point
//
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "GPTheme.h"
#import "GPMemory.h"
#import "GPIl2cpp.h"
#import "GPConfig.h"
#import "GPFeatures.h"
#import "GPPanel.h"
#import "GPOverlay.h"

static UIWindow *gGPWindow = nil;

@interface GPPassView : UIView @end
@implementation GPPassView
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)e {
    UIView *h = [super hitTest:p withEvent:e];
    return (h == self) ? nil : h;
}
@end

static void GPBoot(void) {
    if (gGPWindow) return;

    GPMemoryInit();
    GPConfigLoad();

    UIWindow *w = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    w.windowLevel = UIWindowLevelAlert + 100;
    w.backgroundColor = [UIColor clearColor];

    UIViewController *vc = [UIViewController new];
    vc.view = [[GPPassView alloc] initWithFrame:w.bounds];
    vc.view.backgroundColor = [UIColor clearColor];
    vc.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    w.rootViewController = vc;
    w.hidden = NO;
    gGPWindow = w;

    [[GPPanel shared] attachTo:vc.view];
    [GPOverlay shared].hidden = NO;
    GPFeaturesStart();

    NSLog(@"[GustavoPanel] carregado. base=0x%llX il2cpp=%d", GPBaseAddress(), GPIl2cppReady());
}

__attribute__((constructor))
static void GPDylibInit(void) {
    @autoreleasepool {
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc addObserverForName:UIApplicationDidFinishLaunchingNotification
                        object:nil queue:[NSOperationQueue mainQueue]
                    usingBlock:^(NSNotification *n){ GPBoot(); }];
        [nc addObserverForName:UIApplicationDidBecomeActiveNotification
                        object:nil queue:[NSOperationQueue mainQueue]
                    usingBlock:^(NSNotification *n){ GPBoot(); }];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{ GPBoot(); });
    }
}
