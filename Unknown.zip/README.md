# GUSTAVO PANEL

painel injetor externo (dylib) pra Free Fire no iPhone. preto / azul / branco.

## compilar
opcao A (sem mac): sobe num repo do github -> Actions -> "build gustavo panel" -> Run workflow.
opcao B (com mac): brew install ldid dpkg; export THEOS=~/theos; make

## injetar
python3 inject.py FreeFire.ipa GustavoPanel.dylib
(precisa de IPA DESCRIPTOGRAFADO)

## instalar
assina o ipa gerado no ESign e instala.

## metodo safe
liga a funcao com o jogo fechado -> abre o ff -> nos 40% desliga -> joga -> booyah -> fecha -> repete.
