#import <Foundation/Foundation.h>
#include <stdint.h>
#include <stddef.h>

void     GPMemoryInit(void);
uint64_t GPBaseAddress(void);
uint64_t GPTextSize(void);

BOOL GPRead(uint64_t addr, void *buf, size_t len);
BOOL GPWrite(uint64_t addr, const void *buf, size_t len);

uint64_t GPReadPtr(uint64_t addr);
uint32_t GPReadU32(uint64_t addr);
int32_t  GPReadI32(uint64_t addr);
float    GPReadF32(uint64_t addr);
BOOL     GPWriteF32(uint64_t addr, float v);
NSString *GPReadCSharpString(uint64_t addr);
BOOL      GPIsReadable(uint64_t addr, size_t len);

uint64_t GPScanRange(NSString *sig, uint64_t start, uint64_t size);
uint64_t GPScanSignature(NSString *sig);
BOOL     GPPatch(uint64_t addr, const void *bytes, size_t len);
