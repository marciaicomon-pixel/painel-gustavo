#import "GPOverlay.h"
#import "GPTheme.h"

@interface GPESPView : UIView @end
@implementation GPESPView
- (BOOL)pointInside:(CGPoint)p withEvent:(UIEvent *)e { return NO; }

- (void)drawRect:(CGRect)r {
    CGContextRef c = UIGraphicsGetCurrentContext();
    if (!c) return;
    CGContextSetLineWidth(c, MAX(1.0f, GPF(@"esp_width")));

    for (GPEntity *e in GPEntities()) {
        if (!e.onScreen) continue;
        if (e.team && !GPB(@"esp_team")) continue;

        CGRect box = CGRectMake(e.sHead.x, e.sHead.y,
                                fabs(e.sFeet.x - e.sHead.x) * 0.9f,
                                e.sFeet.y - e.sHead.y);
        if (box.size.width < 4 || box.size.height < 4) continue;

        if (GPB(@"esp_box")) {
            CGContextSetStrokeColorWithColor(c, GP_BLUE.CGColor);
            CGContextStrokeRect(c, box);
        }
        if (GPB(@"esp_line")) {
            CGContextSetStrokeColorWithColor(c, GP_WHITE.CGColor);
            CGContextBeginPath(c);
            CGContextMoveToPoint(c, self.bounds.size.width * 0.5f, self.bounds.size.height - 12);
            CGContextAddLineToPoint(c, e.sFeet.x, e.sFeet.y);
            CGContextStrokePath(c);
        }
        if (GPB(@"esp_health")) {
            float hp = e.maxHealth > 1 ? e.health / e.maxHealth : 1.0f;
            hp = MAX(0.0f, MIN(1.0f, hp));
            CGContextSetFillColorWithColor(c, GP_GREEN.CGColor);
            CGContextFillRect(c, CGRectMake(box.origin.x - 6,
                                            box.origin.y + box.size.height * (1 - hp),
                                            3, box.size.height * hp));
        }
        if (GPB(@"esp_name") && e.name.length) {
            CGSize ts = [e.name sizeWithAttributes:@{NSFontAttributeName: GPFont(11)}];
            CGRect bg = CGRectMake(box.origin.x, box.origin.y - 17, ts.width + 6, 15);
            [[UIColor colorWithWhite:0.1 alpha:0.75] set];
            CGContextFillRect(c, bg);
            [e.name drawAtPoint:CGPointMake(bg.origin.x + 3, bg.origin.y + 1)
                 withAttributes:@{NSFontAttributeName: GPFont(11),
                                  NSForegroundColorAttributeName: GP_WHITE}];
        }
        if (GPB(@"esp_dist")) {
            NSString *d = [NSString stringWithFormat:@"%.0fm", e.dist];
            [d drawAtPoint:CGPointMake(box.origin.x, box.origin.y + box.size.height + 2)
            withAttributes:@{NSFontAttributeName: GPFont(10),
                             NSForegroundColorAttributeName: GP_BLUE}];
        }
    }
}
@end

@interface GPOverlay ()
@property (nonatomic, strong) GPESPView *esp;
@end

@implementation GPOverlay
+ (instancetype)shared {
    static GPOverlay *o = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        o = [[GPOverlay alloc] initWithFrame:[UIScreen mainScreen].bounds];
        o.windowLevel = UIWindowLevelAlert + 101;
        o.backgroundColor = [UIColor clearColor];
        o.rootViewController = [UIViewController new];
        o.rootViewController.view.backgroundColor = [UIColor clearColor];
        o.esp = [[GPESPView alloc] initWithFrame:o.bounds];
        o.esp.backgroundColor = [UIColor clearColor];
        o.esp.opaque = NO;
        o.esp.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [o.rootViewController.view addSubview:o.esp];
        o.hidden = NO;
    });
    return o;
}
- (void)refresh {
    self.frame = [UIScreen mainScreen].bounds;
    self.esp.frame = self.bounds;
    [self.esp setNeedsDisplay];
}
@end
