#import "GPMemory.h"
#import <mach/mach.h>
#import <mach-o/dyld.h>
#import <mach-o/getsect.h>
#import <string.h>
#import <stdlib.h>

static uint64_t gBase = 0;
static uint64_t gText = 0;

void GPMemoryInit(void) {
    if (gBase) return;
    const struct mach_header_64 *h = (const struct mach_header_64 *)_dyld_get_image_header(0);
    if (!h) return;
    gBase = (uint64_t)h;
    const struct segment_command_64 *seg = getsegbyname("__TEXT");
    gText = seg ? seg->vmsize : 0x4000000;
}

uint64_t GPBaseAddress(void) { return gBase; }
uint64_t GPTextSize(void)    { return gText; }

BOOL GPRead(uint64_t addr, void *buf, size_t len) {
    if (!addr || !buf || !len) return NO;
    mach_vm_size_t out = 0;
    kern_return_t kr = mach_vm_read_overwrite(mach_task_self(), addr, len,
                                              (mach_vm_address_t)buf, &out);
    return (kr == KERN_SUCCESS && out == len);
}

BOOL GPWrite(uint64_t addr, const void *buf, size_t len) {
    if (!addr || !buf || !len) return NO;
    kern_return_t kr = mach_vm_write(mach_task_self(), addr, (vm_offset_t)buf,
                                     (mach_msg_type_number_t)len);
    if (kr != KERN_SUCCESS) {
        vm_size_t pg = vm_page_size;
        mach_vm_address_t a = addr & ~((mach_vm_address_t)pg - 1);
        mach_vm_protect(mach_task_self(), a, pg, NO,
                        VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
        kr = mach_vm_write(mach_task_self(), addr, (vm_offset_t)buf,
                           (mach_msg_type_number_t)len);
    }
    return kr == KERN_SUCCESS;
}

uint64_t GPReadPtr(uint64_t a){ uint64_t v=0; GPRead(a,&v,8); return v; }
uint32_t GPReadU32(uint64_t a){ uint32_t v=0; GPRead(a,&v,4); return v; }
int32_t  GPReadI32(uint64_t a){ int32_t v=0;  GPRead(a,&v,4); return v; }
float    GPReadF32(uint64_t a){ float v=0;    GPRead(a,&v,4); return v; }
BOOL GPWriteF32(uint64_t a, float v){ return GPWrite(a,&v,4); }

NSString *GPReadCSharpString(uint64_t addr) {
    if (!addr) return nil;
    int32_t len = GPReadI32(addr + 0x10);
    if (len <= 0 || len > 64) return nil;
    uint16_t buf[65];
    if (!GPRead(addr + 0x14, buf, len * 2)) return nil;
    return [NSString stringWithCharacters:buf length:len];
}

BOOL GPIsReadable(uint64_t addr, size_t len) {
    if (!addr) return NO;
    vm_size_t sz = 0;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t cnt = VM_REGION_BASIC_INFO_COUNT_64;
    mach_port_t obj = MACH_PORT_NULL;
    kern_return_t kr = mach_vm_region(mach_task_self(), (mach_vm_address_t *)&addr,
                                      (mach_vm_size_t *)&sz, VM_REGION_BASIC_INFO_64,
                                      (vm_region_info_t)&info, &cnt, &obj);
    if (kr != KERN_SUCCESS) return NO;
    return (addr + len) <= (addr + sz);
}

uint64_t GPScanRange(NSString *sig, uint64_t start, uint64_t size) {
    if (!sig.length || !start || !size) return 0;
    NSArray *parts = [sig componentsSeparatedByString:@" "];
    size_t plen = parts.count;
    if (!plen || plen > 64) return 0;

    uint8_t pat[64]; char msk[64];
    for (size_t i = 0; i < plen; i++) {
        NSString *p = parts[i];
        if ([p isEqualToString:@"?"] || [p isEqualToString:@"??"]) { msk[i]=0; pat[i]=0; }
        else { pat[i] = (uint8_t)strtol([p UTF8String], NULL, 16); msk[i]=1; }
    }

    const size_t CHUNK = 1 << 20;
    uint8_t *buf = (uint8_t *)malloc(CHUNK + plen);
    uint64_t found = 0;
    for (uint64_t off = 0; off < size && !found; off += CHUNK) {
        size_t want = (size - off) < CHUNK ? (size_t)(size - off) : CHUNK;
        if (!GPRead(start + off, buf, want)) continue;
        for (size_t i = 0; i + plen <= want; i++) {
            BOOL ok = YES;
            for (size_t j = 0; j < plen; j++)
                if (msk[j] && buf[i+j] != pat[j]) { ok = NO; break; }
            if (ok) { found = start + off + i; break; }
        }
    }
    free(buf);
    return found;
}

uint64_t GPScanSignature(NSString *sig) { return GPScanRange(sig, gBase, gText); }
BOOL GPPatch(uint64_t addr, const void *bytes, size_t len) { return GPWrite(addr, bytes, len); }
