#import <UIKit/UIKit.h>
#import "GPFeatures.h"
@interface GPOverlay : UIWindow
+ (instancetype)shared;
- (void)refresh;
@end
