#import "GPFeatures.h"
#import "GPConfig.h"
#import "GPMemory.h"
#import "GPIl2cpp.h"
#import <QuartzCore/QuartzCore.h>
#import <math.h>

@implementation GPItem
+ (instancetype)kind:(GPKind)k title:(NSString *)t key:(NSString *)key tab:(NSString *)tab {
    GPItem *i = [GPItem new];
    i.kind = k; i.title = t; i.key = key; i.tab = tab; i.min = 0; i.max = 1;
    return i;
}
@end
@implementation GPEntity @end

static NSArray *gItems = nil;

NSArray<GPItem *> *GPFeatureList(void) {
    if (gItems) return gItems;
    NSMutableArray *a = [NSMutableArray array];
    #define SW(t,k,tb) [a addObject:[GPItem kind:GPKindSwitch title:t key:k tab:tb]]
    #define SL(t,k,tb,lo,hi) do { GPItem *i=[GPItem kind:GPKindSlider title:t key:k tab:tb]; i.min=lo; i.max=hi; [a addObject:i]; } while(0)
    #define BT(t,k,tb) [a addObject:[GPItem kind:GPKindButton title:t key:k tab:tb]]
    #define IN(t,tb)   [a addObject:[GPItem kind:GPKindInfo title:t key:@"" tab:tb]]

    SW(@"ESP caixa", @"esp_box", @"VISUAIS");
    SW(@"ESP linha", @"esp_line", @"VISUAIS");
    SW(@"ESP esqueleto", @"esp_skeleton", @"VISUAIS");
    SW(@"ESP nome", @"esp_name", @"VISUAIS");
    SW(@"ESP vida", @"esp_health", @"VISUAIS");
    SW(@"ESP distancia", @"esp_dist", @"VISUAIS");
    SW(@"mostrar time", @"esp_team", @"VISUAIS");
    SL(@"distancia maxima", @"esp_max", @"VISUAIS", 20, 400);
    SL(@"espessura", @"esp_width", @"VISUAIS", 1, 4);

    SW(@"aimbot", @"aim_on", @"AIMBOT");
    SW(@"so visivel", @"aim_visible", @"AIMBOT");
    SW(@"mirar na cabeca", @"aim_head", @"AIMBOT");
    SL(@"fov do aim", @"aim_fov", @"AIMBOT", 10, 400);
    SL(@"suavidade", @"aim_smooth", @"AIMBOT", 1, 20);
    SL(@"alcance", @"aim_dist", @"AIMBOT", 10, 300);

    SW(@"no recoil", @"no_recoil", @"EXTRAS");
    SW(@"no spread", @"no_spread", @"EXTRAS");
    SL(@"velocidade", @"speed", @"EXTRAS", 0.5, 5.0);
    SW(@"antenna", @"antenna", @"EXTRAS");
    SW(@"recarga rapida", @"fast_reload", @"EXTRAS");
    SW(@"municao infinita", @"ammo", @"EXTRAS");
    SW(@"wallhack", @"wallhack", @"EXTRAS");
    SL(@"altura da camera", @"cam_height", @"EXTRAS", 0.5, 3.0);

    IN(@"base", @"INFO");
    IN(@"il2cpp", @"INFO");
    IN(@"jogadores", @"INFO");
    BT(@"dump il2cpp", @"act_dump", @"INFO");
    BT(@"testar leitura", @"act_test", @"INFO");
    BT(@"resetar tudo", @"act_reset", @"INFO");
    #undef SW
    #undef SL
    #undef BT
    #undef IN
    gItems = a;
    return gItems;
}

static CADisplayLink *gLink = nil;
static NSMutableArray<GPEntity *> *gEnts = nil;
static uint64_t gLocalPtr = 0, gClassLocal = 0;
static GPVec3 gCamPos, gCamRot;
static float gSW = 0, gSH = 0;
static size_t gOffPos=0,gOffHead=0,gOffHealth=0,gOffMaxHp=0,gOffTeam=0,gOffName=0,gOffRot=0;

NSArray<GPEntity *> *GPEntities(void) { return gEnts ?: @[]; }

static void GPResolveFields(void) {
    if (gClassLocal) return;
    gClassLocal = (uint64_t)GPIl2cppClass(GPS(@"prof_image").UTF8String, "",
                                          GPS(@"prof_class").UTF8String);
    if (!gClassLocal) return;
    void *k = (void *)gClassLocal;
    gOffPos    = GPIl2cppFieldOffset(k, "pos") ?: GPIl2cppFieldOffset(k, "position");
    gOffHead   = GPIl2cppFieldOffset(k, "head");
    gOffHealth = GPIl2cppFieldOffset(k, "health") ?: GPIl2cppFieldOffset(k, "hp");
    gOffMaxHp  = GPIl2cppFieldOffset(k, "maxHealth");
    gOffTeam   = GPIl2cppFieldOffset(k, "team");
    gOffName   = GPIl2cppFieldOffset(k, "name");
    gOffRot    = GPIl2cppFieldOffset(k, "rot") ?: GPIl2cppFieldOffset(k, "aimRot");
}

static CGPoint GPWorldToScreen(GPVec3 w) {
    float dx = w.x - gCamPos.x, dy = w.y - gCamPos.y, dz = w.z - gCamPos.z;
    float cy = cosf(-gCamRot.y * (float)M_PI / 180.0f);
    float sy = sinf(-gCamRot.y * (float)M_PI / 180.0f);
    float cp = cosf(-gCamRot.x * (float)M_PI / 180.0f);
    float sp = sinf(-gCamRot.x * (float)M_PI / 180.0f);
    float x1 =  dx * cy - dz * sy;
    float z1 =  dx * sy + dz * cy;
    float y2 =  dy * cp - z1 * sp;
    float z2 =  dy * sp + z1 * cp;
    if (z2 <= 0.01f) return CGPointMake(-9999, -9999);
    float fov = GPF(@"cam_fov"); if (fov < 20) fov = 95;
    float f = (gSH * 0.5f) / tanf(fov * (float)M_PI / 360.0f);
    return CGPointMake(gSW * 0.5f + (x1 / z2) * f, gSH * 0.5f - (y2 / z2) * f);
}

void GPFeaturesTick(void) {
    if (!gEnts) gEnts = [NSMutableArray array];
    CGSize sc = [UIScreen mainScreen].bounds.size;
    gSW = MAX(sc.width, sc.height);
    gSH = MIN(sc.width, sc.height);

    if (!GPB(@"master")) { [gEnts removeAllObjects]; return; }
    GPResolveFields();
    if (!gClassLocal) { [gEnts removeAllObjects]; return; }

    void *fLocal = GPIl2cppField((void *)gClassLocal, GPS(@"prof_local").UTF8String);
    if (fLocal) { uint64_t p = 0; if (GPIl2cppStaticValue(fLocal, &p)) gLocalPtr = p; }
    if (!gLocalPtr) { [gEnts removeAllObjects]; return; }

    if (gOffPos) { GPRead(gLocalPtr + gOffPos, &gCamPos, sizeof(GPVec3)); gCamPos.y += GPF(@"cam_height"); }
    if (gOffRot) GPRead(gLocalPtr + gOffRot, &gCamRot, sizeof(GPVec3));

    [gEnts removeAllObjects];

    void *fList = GPIl2cppField((void *)gClassLocal, GPS(@"prof_list").UTF8String);
    uint64_t listPtr = 0;
    if (fList) GPIl2cppStaticValue(fList, &listPtr);

    if (listPtr) {
        int32_t count = GPReadI32(listPtr + 0x18);
        uint64_t items = GPReadPtr(listPtr + 0x10);
        if (count > 0 && count < 64 && items) {
            for (int i = 0; i < count; i++) {
                uint64_t p = GPReadPtr(items + 8 * i);
                if (!p || p == gLocalPtr) continue;
                GPEntity *e = [GPEntity new];
                e.ptr = p;
                if (gOffPos)  GPRead(p + gOffPos, &e.pos, sizeof(GPVec3));
                if (gOffHead) GPRead(p + gOffHead, &e.head, sizeof(GPVec3)); else e.head = e.pos;
                if (gOffHealth) e.health = GPReadF32(p + gOffHealth);
                if (gOffMaxHp)  e.maxHealth = GPReadF32(p + gOffMaxHp);
                if (gOffTeam)   e.team = GPReadI32(p + gOffTeam) == GPReadI32(gLocalPtr + gOffTeam);
                if (gOffName)   e.name = GPReadCSharpString(GPReadPtr(p + gOffName));
                float dx = e.pos.x - gCamPos.x, dy = e.pos.y - gCamPos.y, dz = e.pos.z - gCamPos.z;
                e.dist = sqrtf(dx*dx + dy*dy + dz*dz);
                if (e.dist > GPF(@"esp_max") + 50) continue;
                e.sHead = GPWorldToScreen(e.head);
                e.sFeet = GPWorldToScreen(e.pos);
                e.onScreen = (e.sHead.x > -9000 && e.sFeet.x > -9000);
                [gEnts addObject:e];
            }
        }
    }

    if (GPB(@"aim_on") && gEnts.count && gOffRot) {
        float best = GPF(@"aim_fov"), cx = gSW * 0.5f, cy = gSH * 0.5f;
        GPEntity *target = nil;
        for (GPEntity *e in gEnts) {
            if (e.team && !GPB(@"esp_team")) continue;
            if (e.dist > GPF(@"aim_dist") || !e.onScreen) continue;
            float d = sqrtf((e.sHead.x-cx)*(e.sHead.x-cx) + (e.sHead.y-cy)*(e.sHead.y-cy));
            if (d < best) { best = d; target = e; }
        }
        if (target) {
            GPVec3 t = GPB(@"aim_head") ? target.head : target.pos;
            float dx = t.x - gCamPos.x, dy = t.y - gCamPos.y, dz = t.z - gCamPos.z;
            float yaw   = atan2f(dx, dz) * 180.0f / (float)M_PI;
            float pitch = -atan2f(dy, sqrtf(dx*dx + dz*dz)) * 180.0f / (float)M_PI;
            float sm = GPF(@"aim_smooth"); if (sm < 1) sm = 1;
            GPWriteF32(gLocalPtr + gOffRot, gCamRot.x + (pitch - gCamRot.x) / sm);
            GPWriteF32(gLocalPtr + gOffRot + 4, gCamRot.y + (yaw - gCamRot.y) / sm);
        }
    }
}

@interface GPTicker : NSObject
+ (instancetype)shared;
- (void)step;
@end
@implementation GPTicker
+ (instancetype)shared { static GPTicker *t; static dispatch_once_t o; dispatch_once(&o, ^{ t=[GPTicker new]; }); return t; }
- (void)step { GPFeaturesTick(); [[GPOverlay shared] refresh]; }
@end

void GPFeaturesStart(void) {
    if (gLink) return;
    gEnts = [NSMutableArray array];
    gLink = [CADisplayLink displayLinkWithTarget:[GPTicker shared] selector:@selector(step)];
    [gLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}

void GPFeaturesApply(NSString *key) { if ([key isEqualToString:@"act_reset"]) GPConfigReset(); }

NSString *GPStatsLine(void) {
    return [NSString stringWithFormat:@"%lu inimigos  base 0x%llX",
            (unsigned long)gEnts.count, GPBaseAddress()];
}
