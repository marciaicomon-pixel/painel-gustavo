#import <Foundation/Foundation.h>

void  GPConfigLoad(void);
void  GPConfigReset(void);
void  GPConfigSave(void);
BOOL  GPB(NSString *key);
float GPF(NSString *key);
void  GPSetB(NSString *key, BOOL v);
void  GPSetF(NSString *key, float v);
NSString *GPS(NSString *key);
