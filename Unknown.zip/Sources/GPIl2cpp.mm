#import "GPIl2cpp.h"
#import <dlfcn.h>
#import <mach-o/dyld.h>

typedef void   *(*fn_domain_get)(void);
typedef void   *(*fn_thread_attach)(void *);
typedef size_t  (*fn_domain_get_assemblies)(void *, size_t *);
typedef void   *(*fn_assembly_get_image)(void *);
typedef const char *(*fn_image_get_name)(void *);
typedef void   *(*fn_class_from_name)(void *, const char *, const char *);
typedef size_t  (*fn_image_get_class_count)(void *);
typedef void   *(*fn_image_get_class)(void *, size_t);
typedef const char *(*fn_class_get_name)(void *);
typedef void   *(*fn_class_get_field_from_name)(void *, const char *);
typedef size_t  (*fn_field_get_offset)(void *);
typedef void    (*fn_field_static_get_value)(void *, void *);
typedef void   *(*fn_class_get_methods)(void *, void **);
typedef const char *(*fn_method_get_name)(void *);

static struct {
    fn_domain_get domain_get;
    fn_thread_attach thread_attach;
    fn_domain_get_assemblies domain_get_assemblies;
    fn_assembly_get_image assembly_get_image;
    fn_image_get_name image_get_name;
    fn_class_from_name class_from_name;
    fn_image_get_class_count image_get_class_count;
    fn_image_get_class image_get_class;
    fn_class_get_name class_get_name;
    fn_class_get_field_from_name class_get_field_from_name;
    fn_field_get_offset field_get_offset;
    fn_field_static_get_value field_static_get_value;
    fn_class_get_methods class_get_methods;
    fn_method_get_name method_get_name;
} gI;

static BOOL gOk = NO;
static void *gDomain = NULL;
static NSRecursiveLock *gLock = nil;

static void *GPResolve(const char *n, void *h) {
    void *p = dlsym(h, n);
    return p ? p : dlsym(RTLD_DEFAULT, n);
}

BOOL GPIl2cppInit(void) {
    if (gOk) return YES;
    if (!gLock) gLock = [NSRecursiveLock new];
    [gLock lock];

    void *handles[8]; int hi = 0;
    handles[hi++] = RTLD_DEFAULT;
    uint32_t n = _dyld_image_count();
    for (uint32_t i = 0; i < n && hi < 8; i++) {
        const char *p = _dyld_get_image_name(i);
        if (!p) continue;
        NSString *s = [NSString stringWithUTF8String:p];
        if ([s containsString:@"UnityFramework"] || [s containsString:@".app/"]) {
            void *h = dlopen(p, RTLD_NOW | RTLD_NOLOAD);
            if (h) handles[hi++] = h;
        }
    }

    for (int i = 0; i < hi; i++) {
        void *h = handles[i];
        gI.domain_get = (fn_domain_get)GPResolve("il2cpp_domain_get", h);
        if (gI.domain_get) {
            gI.thread_attach = (fn_thread_attach)GPResolve("il2cpp_thread_attach", h);
            gI.domain_get_assemblies = (fn_domain_get_assemblies)GPResolve("il2cpp_domain_get_assemblies", h);
            gI.assembly_get_image = (fn_assembly_get_image)GPResolve("il2cpp_assembly_get_image", h);
            gI.image_get_name = (fn_image_get_name)GPResolve("il2cpp_image_get_name", h);
            gI.class_from_name = (fn_class_from_name)GPResolve("il2cpp_class_from_name", h);
            gI.image_get_class_count = (fn_image_get_class_count)GPResolve("il2cpp_image_get_class_count", h);
            gI.image_get_class = (fn_image_get_class)GPResolve("il2cpp_image_get_class", h);
            gI.class_get_name = (fn_class_get_name)GPResolve("il2cpp_class_get_name", h);
            gI.class_get_field_from_name = (fn_class_get_field_from_name)GPResolve("il2cpp_class_get_field_from_name", h);
            gI.field_get_offset = (fn_field_get_offset)GPResolve("il2cpp_field_get_offset", h);
            gI.field_static_get_value = (fn_field_static_get_value)GPResolve("il2cpp_field_static_get_value", h);
            gI.class_get_methods = (fn_class_get_methods)GPResolve("il2cpp_class_get_methods", h);
            gI.method_get_name = (fn_method_get_name)GPResolve("il2cpp_method_get_name", h);
            break;
        }
    }

    if (gI.domain_get) {
        gDomain = gI.domain_get();
        if (gI.thread_attach && gDomain) gI.thread_attach(gDomain);
        gOk = (gDomain != NULL);
    }
    [gLock unlock];
    return gOk;
}

BOOL GPIl2cppReady(void) { return gOk; }

NSString *GPIl2cppStatus(void) {
    return gOk ? [NSString stringWithFormat:@"il2cpp: ok  domain=0x%llX", (uint64_t)gDomain]
               : @"il2cpp: nao resolvido";
}

static void *GPImageUnlocked(const char *imageName) {
    if (!gOk || !imageName) return NULL;
    size_t cnt = 0;
    void **asms = (void **)gI.domain_get_assemblies(gDomain, &cnt);
    for (size_t i = 0; i < cnt; i++) {
        void *img = gI.assembly_get_image(asms[i]);
        const char *n = gI.image_get_name ? gI.image_get_name(img) : NULL;
        if (n && strcmp(n, imageName) == 0) return img;
    }
    return NULL;
}

void *GPIl2cppClass(const char *imageName, const char *ns, const char *className) {
    if (!GPIl2cppInit()) return NULL;
    [gLock lock];
    void *img = GPImageUnlocked(imageName);
    void *k = img ? gI.class_from_name(img, ns ? ns : "", className) : NULL;
    [gLock unlock];
    return k;
}

void *GPIl2cppField(void *klass, const char *fieldName) {
    if (!gOk || !klass || !fieldName) return NULL;
    [gLock lock];
    void *f = gI.class_get_field_from_name(klass, fieldName);
    [gLock unlock];
    return f;
}

size_t GPIl2cppFieldOffset(void *klass, const char *fieldName) {
    void *f = GPIl2cppField(klass, fieldName);
    if (!f || !gI.field_get_offset) return 0;
    [gLock lock];
    size_t o = gI.field_get_offset(f);
    [gLock unlock];
    return o;
}

BOOL GPIl2cppStaticValue(void *field, void *out) {
    if (!gOk || !field || !out || !gI.field_static_get_value) return NO;
    [gLock lock];
    gI.field_static_get_value(field, out);
    [gLock unlock];
    return YES;
}

NSString *GPIl2cppDump(NSInteger maxClasses) {
    if (!GPIl2cppInit()) return @"il2cpp nao resolvido";
    NSMutableString *s = [NSMutableString string];
    [gLock lock];
    size_t cnt = 0;
    void **asms = (void **)gI.domain_get_assemblies(gDomain, &cnt);
    for (size_t i = 0; i < cnt; i++) {
        void *img = gI.assembly_get_image(asms[i]);
        const char *in = gI.image_get_name ? gI.image_get_name(img) : "?";
        if (!in || !strstr(in, "Assembly-CSharp")) continue;
        [s appendFormat:@"== %s ==\n", in];
        size_t cc = gI.image_get_class_count ? gI.image_get_class_count(img) : 0;
        for (size_t c = 0; c < cc && (NSInteger)c < maxClasses; c++) {
            void *k = gI.image_get_class(img, c);
            const char *kn = gI.class_get_name ? gI.class_get_name(k) : NULL;
            if (!kn) continue;
            [s appendFormat:@"class %s\n", kn];
            void *it = NULL; int mc = 0;
            while (gI.class_get_methods && mc < 10) {
                void *m = gI.class_get_methods(k, &it);
                if (!m) break;
                const char *mn = gI.method_get_name ? gI.method_get_name(m) : NULL;
                if (mn) { [s appendFormat:@"   m %s\n", mn]; mc++; }
            }
        }
    }
    [gLock unlock];
    return s;
}
