//
//  GPTheme.h - preto / azul / branco
//
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

#define GP_BLACK   [UIColor colorWithRed:0.039 green:0.055 blue:0.078 alpha:1.0]
#define GP_CARD    [UIColor colorWithRed:0.082 green:0.110 blue:0.149 alpha:1.0]
#define GP_BLUE    [UIColor colorWithRed:0.118 green:0.435 blue:1.000 alpha:1.0]
#define GP_BLUE_D  [UIColor colorWithRed:0.075 green:0.290 blue:0.760 alpha:1.0]
#define GP_WHITE   [UIColor colorWithWhite:0.97 alpha:1.0]
#define GP_GRAY    [UIColor colorWithWhite:0.62 alpha:1.0]
#define GP_DIM     [UIColor colorWithWhite:0.42 alpha:1.0]
#define GP_GREEN   [UIColor colorWithRed:0.133 green:0.773 blue:0.369 alpha:1.0]

static inline UIFont *GPFont(CGFloat s) {
    UIFont *f = [UIFont fontWithName:@"AvenirNext-DemiBold" size:s];
    return f ?: [UIFont boldSystemFontOfSize:s];
}
static inline UILabel *GPLabel(NSString *t, CGFloat s, UIColor *c) {
    UILabel *l = [UILabel new];
    l.text = t; l.font = GPFont(s); l.textColor = c;
    l.backgroundColor = [UIColor clearColor];
    return l;
}
static inline UISwitch *GPNewSwitch(void) {
    UISwitch *s = [UISwitch new];
    s.onTintColor = GP_BLUE;
    s.transform = CGAffineTransformMakeScale(0.72, 0.72);
    return s;
}
static inline UISlider *GPNewSlider(void) {
    UISlider *s = [UISlider new];
    s.minimumTrackTintColor = GP_BLUE;
    s.maximumTrackTintColor = [UIColor colorWithWhite:0.22 alpha:1.0];
    s.thumbTintColor = GP_WHITE;
    return s;
}
static inline UIButton *GPButton(NSString *t, UIColor *bg, UIColor *fg) {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    [b setTitle:t forState:UIControlStateNormal];
    [b setTitleColor:fg forState:UIControlStateNormal];
    b.titleLabel.font = GPFont(13);
    b.backgroundColor = bg;
    b.layer.cornerRadius = 9;
    return b;
}
