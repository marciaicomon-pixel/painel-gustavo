#import <UIKit/UIKit.h>
@interface GPPanel : UIViewController
+ (instancetype)shared;
- (void)attachTo:(UIView *)host;
@end
