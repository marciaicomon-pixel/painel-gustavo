#import "GPConfig.h"

static NSUserDefaults *gUD = nil;

static NSDictionary *GPDefaults(void) {
    return @{
        @"master": @YES,
        @"esp_box": @YES, @"esp_line": @NO, @"esp_name": @YES, @"esp_health": @YES,
        @"esp_dist": @YES, @"esp_team": @NO, @"esp_skeleton": @NO,
        @"esp_max": @180.0f, @"esp_width": @1.5f,
        @"aim_on": @NO, @"aim_visible": @NO, @"aim_head": @YES,
        @"aim_fov": @120.0f, @"aim_smooth": @4.0f, @"aim_dist": @120.0f,
        @"no_recoil": @NO, @"no_spread": @NO, @"speed": @1.0f,
        @"antenna": @NO, @"fast_reload": @NO, @"ammo": @NO, @"wallhack": @NO,
        @"cam_fov": @95.0f, @"cam_height": @1.55f,
        @"prof_image": @"Assembly-CSharp.dll",
        @"prof_class": @"Player",
        @"prof_local": @"LocalPlayer",
        @"prof_list": @"Players",
    };
}

void GPConfigLoad(void) {
    if (gUD) return;
    gUD = [NSUserDefaults standardUserDefaults];
    [gUD registerDefaults:GPDefaults()];
}
void GPConfigSave(void) { if (gUD) [gUD synchronize]; }
void GPConfigReset(void) {
    NSDictionary *d = GPDefaults();
    for (NSString *k in d) [gUD setObject:d[k] forKey:k];
    [gUD synchronize];
}
BOOL GPB(NSString *k) { GPConfigLoad(); return [gUD boolForKey:k]; }
float GPF(NSString *k){ GPConfigLoad(); return [gUD floatForKey:k]; }
NSString *GPS(NSString *k){ GPConfigLoad(); return [gUD stringForKey:k]; }
void GPSetB(NSString *k, BOOL v){ GPConfigLoad(); [gUD setBool:v forKey:k]; }
void GPSetF(NSString *k, float v){ GPConfigLoad(); [gUD setFloat:v forKey:k]; }
