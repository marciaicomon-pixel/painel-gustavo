#import <Foundation/Foundation.h>
#include <stdint.h>

BOOL     GPIl2cppInit(void);
BOOL     GPIl2cppReady(void);
NSString *GPIl2cppStatus(void);
void    *GPIl2cppClass(const char *imageName, const char *ns, const char *className);
size_t   GPIl2cppFieldOffset(void *klass, const char *fieldName);
void    *GPIl2cppField(void *klass, const char *fieldName);
BOOL     GPIl2cppStaticValue(void *field, void *out);
NSString *GPIl2cppDump(NSInteger maxClasses);
