#import "GPPanel.h"
#import "GPTheme.h"
#import "GPConfig.h"
#import "GPFeatures.h"

static const CGFloat kPanelW = 312;
static const CGFloat kPanelH = 476;

@interface GPPanel ()
@property (nonatomic, strong) UIButton *fab;
@property (nonatomic, strong) UIView *panel;
@property (nonatomic, strong) UIScrollView *scroll;
@property (nonatomic, strong) NSMutableArray<UIButton *> *tabs;
@property (nonatomic, copy) NSString *activeTab;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) UILabel *status;
@end

@implementation GPPanel

+ (instancetype)shared {
    static GPPanel *p = nil; static dispatch_once_t once;
    dispatch_once(&once, ^{ p = [GPPanel new]; });
    return p;
}

- (void)attachTo:(UIView *)host {
    if (self.fab.superview) return;
    [self buildFAB]; [self buildPanel];
    [host addSubview:self.fab]; [host addSubview:self.panel];
    self.activeTab = @"VISUAIS";
    [self buildRows];
    self.panel.hidden = YES;

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rotated)
        name:UIDeviceOrientationDidChangeNotification object:nil];

    __weak GPPanel *w = self;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0 repeats:YES block:^(NSTimer *t){
        if (!w.panel.hidden && [w.activeTab isEqualToString:@"INFO"]) [w buildRows];
    }];
}

- (void)rotated {
    CGRect b = [UIScreen mainScreen].bounds;
    self.fab.frame = CGRectMake(MIN(MAX(0, self.fab.frame.origin.x), b.size.width - 56),
                                MIN(MAX(0, self.fab.frame.origin.y), b.size.height - 56), 56, 56);
    self.panel.frame = CGRectMake(MAX(12, b.size.width - kPanelW - 14),
                                  MAX(10, (b.size.height - kPanelH) / 2), kPanelW, kPanelH);
}

- (void)buildFAB {
    self.fab = [UIButton buttonWithType:UIButtonTypeCustom];
    self.fab.frame = CGRectMake(24, 60, 56, 56);
    self.fab.backgroundColor = [GP_BLACK colorWithAlphaComponent:0.92];
    self.fab.layer.cornerRadius = 28;
    self.fab.layer.borderWidth = 2;
    self.fab.layer.borderColor = GP_BLUE.CGColor;
    [self.fab setTitle:@"G" forState:UIControlStateNormal];
    [self.fab setTitleColor:GP_WHITE forState:UIControlStateNormal];
    self.fab.titleLabel.font = GPFont(24);
    [self.fab addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [self.fab addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self
                                                                          action:@selector(dragFab:)]];
}
- (void)dragFab:(UIPanGestureRecognizer *)g {
    CGPoint t = [g translationInView:self.fab.superview];
    CGPoint c = self.fab.center;
    self.fab.center = CGPointMake(c.x + t.x, c.y + t.y);
    [g setTranslation:CGPointZero inView:self.fab.superview];
}
- (void)togglePanel {
    BOOL show = self.panel.hidden;
    self.panel.hidden = !show;
    if (show) { self.panel.alpha = 0; [UIView animateWithDuration:0.18 animations:^{ self.panel.alpha = 1; }]; }
}

- (void)buildPanel {
    CGRect b = [UIScreen mainScreen].bounds;
    self.panel = [[UIView alloc] initWithFrame:CGRectMake(b.size.width - kPanelW - 14,
                                                         (b.size.height - kPanelH) / 2, kPanelW, kPanelH)];
    self.panel.backgroundColor = [GP_BLACK colorWithAlphaComponent:0.97];
    self.panel.layer.cornerRadius = 18;
    self.panel.layer.borderWidth = 1.5;
    self.panel.layer.borderColor = [GP_BLUE colorWithAlphaComponent:0.65].CGColor;
    self.panel.layer.masksToBounds = YES;

    UIView *head = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kPanelW, 46)];
    head.backgroundColor = [GP_BLUE_D colorWithAlphaComponent:0.28];
    [self.panel addSubview:head];

    UILabel *title = GPLabel(@"GUSTAVO PANEL", 15, GP_WHITE);
    title.frame = CGRectMake(14, 12, 200, 22);
    [head addSubview:title];
    UILabel *ver = GPLabel(@"v1.0", 10, GP_BLUE);
    ver.frame = CGRectMake(14, 29, 60, 12);
    [head addSubview:ver];

    UIButton *close = GPButton(@"X", [UIColor clearColor], GP_WHITE);
    close.frame = CGRectMake(kPanelW - 40, 8, 30, 30);
    [close addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [head addSubview:close];

    self.tabs = [NSMutableArray array];
    NSArray *names = @[@"VISUAIS", @"AIMBOT", @"EXTRAS", @"INFO"];
    CGFloat tw = (kPanelW - 20) / names.count;
    for (NSInteger i = 0; i < names.count; i++) {
        UIButton *t = GPButton(names[i], [UIColor clearColor], GP_GRAY);
        t.titleLabel.font = GPFont(10);
        t.frame = CGRectMake(10 + i * tw, 50, tw - 4, 26);
        t.layer.cornerRadius = 7; t.tag = i;
        [t addTarget:self action:@selector(tabTap:) forControlEvents:UIControlEventTouchUpInside];
        [self.panel addSubview:t];
        [self.tabs addObject:t];
    }

    self.scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 82, kPanelW, kPanelH - 168)];
    self.scroll.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    [self.panel addSubview:self.scroll];

    UIView *foot = [[UIView alloc] initWithFrame:CGRectMake(0, kPanelH - 84, kPanelW, 84)];
    foot.backgroundColor = [GP_CARD colorWithAlphaComponent:0.55];
    [self.panel addSubview:foot];

    UILabel *ml = GPLabel(@"FUNCAO (modo safe)", 12, GP_WHITE);
    ml.frame = CGRectMake(14, 10, 200, 16);
    [foot addSubview:ml];

    UISwitch *ms = GPNewSwitch();
    ms.frame = CGRectMake(kPanelW - 62, 6, 51, 31);
    ms.on = GPB(@"master");
    [ms addTarget:self action:@selector(masterChanged:) forControlEvents:UIControlEventValueChanged];
    [foot addSubview:ms];

    self.status = GPLabel(@"ative com o jogo FECHADO", 9, GP_GREEN);
    self.status.frame = CGRectMake(14, 28, kPanelW - 28, 12);
    [foot addSubview:self.status];

    UIButton *save = GPButton(@"SALVAR", GP_BLUE, GP_WHITE);
    save.frame = CGRectMake(14, 46, (kPanelW - 40) / 2, 28);
    [save addTarget:self action:@selector(saveTap) forControlEvents:UIControlEventTouchUpInside];
    [foot addSubview:save];

    UIButton *rst = GPButton(@"RESET", [UIColor colorWithWhite:0.18 alpha:1], GP_WHITE);
    rst.frame = CGRectMake(26 + (kPanelW - 40) / 2, 46, (kPanelW - 40) / 2, 28);
    [rst addTarget:self action:@selector(resetTap) forControlEvents:UIControlEventTouchUpInside];
    [foot addSubview:rst];

    UILabel *hint = GPLabel(@"safe: liga fechado > abre > desliga nos 40% > booyah > fecha", 8, GP_DIM);
    hint.frame = CGRectMake(14, 74, kPanelW - 28, 10);
    hint.adjustsFontSizeToFitWidth = YES;
    [foot addSubview:hint];
}

- (void)tabTap:(UIButton *)b {
    NSArray *names = @[@"VISUAIS", @"AIMBOT", @"EXTRAS", @"INFO"];
    self.activeTab = names[b.tag];
    [self buildRows];
}
- (void)masterChanged:(UISwitch *)s {
    GPSetB(@"master", s.on);
    self.status.text = s.on ? @"FUNCAO LIGADA - desligue nos 40%" : @"funcao desligada";
    self.status.textColor = s.on ? GP_GREEN : GP_GRAY;
}
- (void)saveTap { GPConfigSave(); self.status.text = @"config salva"; }
- (void)resetTap { GPConfigReset(); [self buildRows]; self.status.text = @"config resetada"; }

- (void)buildRows {
    for (UIView *v in self.scroll.subviews) [v removeFromSuperview];
    for (UIButton *t in self.tabs) {
        BOOL on = [t.titleLabel.text isEqualToString:self.activeTab];
        t.backgroundColor = on ? [GP_BLUE colorWithAlphaComponent:0.9] : [UIColor clearColor];
        [t setTitleColor:on ? GP_WHITE : GP_GRAY forState:UIControlStateNormal];
    }

    CGFloat y = 6;
    for (GPItem *it in GPFeatureList()) {
        if (![it.tab isEqualToString:self.activeTab]) continue;

        UIView *row = [[UIView alloc] initWithFrame:CGRectMake(10, y, kPanelW - 20, 34)];
        row.backgroundColor = [GP_CARD colorWithAlphaComponent:0.75];
        row.layer.cornerRadius = 9;
        [self.scroll addSubview:row];

        if (it.kind == GPKindSwitch) {
            UILabel *l = GPLabel(it.title, 12, GP_WHITE);
            l.frame = CGRectMake(12, 9, kPanelW - 100, 16);
            [row addSubview:l];
            UISwitch *s = GPNewSwitch();
            s.frame = CGRectMake(kPanelW - 76, 2, 51, 31);
            s.on = GPB(it.key);
            objc_setAssociatedObject(s, "k", it.key, OBJC_ASSOCIATION_COPY);
            [s addTarget:self action:@selector(swChanged:) forControlEvents:UIControlEventValueChanged];
            [row addSubview:s];
        } else if (it.kind == GPKindSlider) {
            row.frame = CGRectMake(10, y, kPanelW - 20, 38);
            UILabel *l = GPLabel(it.title, 11, GP_WHITE);
            l.frame = CGRectMake(12, 4, 150, 14);
            [row addSubview:l];
            UILabel *val = GPLabel([NSString stringWithFormat:@"%.1f", GPF(it.key)], 11, GP_BLUE);
            val.frame = CGRectMake(kPanelW - 70, 4, 56, 14);
            val.textAlignment = NSTextAlignmentRight;
            [row addSubview:val];
            UISlider *sl = GPNewSlider();
            sl.frame = CGRectMake(12, 20, kPanelW - 44, 12);
            sl.minimumValue = it.min; sl.maximumValue = it.max; sl.value = GPF(it.key);
            objc_setAssociatedObject(sl, "k", it.key, OBJC_ASSOCIATION_COPY);
            objc_setAssociatedObject(sl, "v", val, OBJC_ASSOCIATION_ASSIGN);
            [sl addTarget:self action:@selector(slChanged:) forControlEvents:UIControlEventValueChanged];
            [row addSubview:sl];
            y += 4;
        } else if (it.kind == GPKindButton) {
            UIButton *b = GPButton(it.title, [GP_BLUE colorWithAlphaComponent:0.85], GP_WHITE);
            b.frame = CGRectMake(8, 4, kPanelW - 36, 26);
            objc_setAssociatedObject(b, "k", it.key, OBJC_ASSOCIATION_COPY);
            [b addTarget:self action:@selector(btnTap:) forControlEvents:UIControlEventTouchUpInside];
            [row addSubview:b];
        } else if (it.kind == GPKindInfo) {
            row.frame = CGRectMake(10, y, kPanelW - 20, 28);
            UILabel *l = GPLabel(@"", 10, GP_GRAY);
            l.numberOfLines = 0;
            l.frame = CGRectMake(12, 4, kPanelW - 40, 24);
            if ([it.title isEqualToString:@"base"])
                l.text = [NSString stringWithFormat:@"base do jogo: 0x%llX", GPBaseAddress()];
            else if ([it.title isEqualToString:@"il2cpp"]) l.text = GPIl2cppStatus();
            else l.text = GPStatsLine();
            [row addSubview:l];
        }
        y += row.frame.size.height + 5;
    }
    self.scroll.contentSize = CGSizeMake(kPanelW, y + 10);
}

- (void)swChanged:(UISwitch *)s { GPSetB(objc_getAssociatedObject(s, "k"), s.on); }
- (void)slChanged:(UISlider *)sl {
    NSString *k = objc_getAssociatedObject(sl, "k");
    UILabel *v = objc_getAssociatedObject(sl, "v");
    GPSetF(k, sl.value);
    v.text = [NSString stringWithFormat:@"%.1f", sl.value];
}
- (void)btnTap:(UIButton *)b {
    NSString *k = objc_getAssociatedObject(b, "k");
    if ([k isEqualToString:@"act_dump"]) {
        NSString *d = GPIl2cppDump(120);
        NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/gustavopanel_dump.txt"];
        [d writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
        self.status.text = @"dump salvo em Documents";
    } else if ([k isEqualToString:@"act_test"]) {
        self.status.text = [NSString stringWithFormat:@"leitura base: 0x%X", GPReadU32(GPBaseAddress())];
    } else GPFeaturesApply(k);
}
@end
