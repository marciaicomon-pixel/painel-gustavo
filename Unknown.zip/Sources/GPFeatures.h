#import <UIKit/UIKit.h>
#include <stdint.h>

typedef struct { float x, y, z; } GPVec3;
typedef NS_ENUM(NSInteger, GPKind) { GPKindSwitch, GPKindSlider, GPKindButton, GPKindInfo };

@interface GPItem : NSObject
@property (nonatomic) GPKind kind;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *key;
@property (nonatomic, copy) NSString *tab;
@property (nonatomic) float min, max;
+ (instancetype)kind:(GPKind)k title:(NSString *)t key:(NSString *)key tab:(NSString *)tab;
@end

@interface GPEntity : NSObject
@property (nonatomic) uint64_t ptr;
@property (nonatomic) GPVec3 pos, head;
@property (nonatomic) float health, maxHealth, dist;
@property (nonatomic) BOOL team, onScreen;
@property (nonatomic) CGPoint sHead, sFeet;
@property (nonatomic, copy) NSString *name;
@end

void GPFeaturesStart(void);
void GPFeaturesTick(void);
void GPFeaturesApply(NSString *key);
NSArray<GPItem *>   *GPFeatureList(void);
NSArray<GPEntity *> *GPEntities(void);
NSString *GPStatsLine(void);
