#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
inject.py - injeta o GustavoPanel.dylib dentro de um IPA do Free Fire.
uso: python3 inject.py FreeFire.ipa GustavoPanel.dylib
"""
import os, struct, shutil, sys, tempfile, zipfile, plistlib

MH_MAGIC_64, FAT_MAGIC, FAT_MAGIC_64 = 0xFEEDFACF, 0xCAFEBABE, 0xCAFEBABF
LC_LOAD_DYLIB, LC_SEGMENT_64 = 0x0C, 0x19
CPU_TYPE_ARM64 = 0x0100000C
DYLIB_PATH = "@executable_path/GustavoPanel.dylib"


def align8(n): return (n + 7) & ~7


def dylib_cmd():
    name = DYLIB_PATH.encode() + b"\x00"
    size = align8(24 + len(name))
    head = struct.pack("<6I", LC_LOAD_DYLIB, size, 24, 0, 0x10000, 0x10000)
    return head + name + b"\x00" * (size - 24 - len(name))


def patch_slice(data):
    magic, cputype, cpusub, ftype, ncmds, sizeofcmds, flags, res = struct.unpack_from("<8I", data, 0)
    if magic != MH_MAGIC_64: return None
    off, first_data = 32, None
    for _ in range(ncmds):
        cmd, cmdsize = struct.unpack_from("<2I", data, off)
        if cmdsize < 8: return None
        if cmd == LC_SEGMENT_64:
            fileoff, filesize = struct.unpack_from("<2Q", data, off + 40)
            if filesize > 0 and fileoff > 0 and (first_data is None or fileoff < first_data):
                first_data = fileoff
            nsects = struct.unpack_from("<I", data, off + 64)[0]
            so = off + 72
            for _ in range(nsects):
                s_off, s_size = struct.unpack_from("<2I", data, so + 40)
                if s_size > 0 and s_off > 0 and (first_data is None or s_off < first_data):
                    first_data = s_off
                so += 80
        off += cmdsize
    if first_data is None: return None
    cmd = dylib_cmd()
    end_lc = 32 + sizeofcmds
    if end_lc + len(cmd) > first_data:
        raise SystemExit("sem espaco no header pra dylib")
    out = bytearray(data)
    out[end_lc:end_lc + len(cmd)] = cmd
    struct.pack_into("<I", out, 16, ncmds + 1)
    struct.pack_into("<I", out, 20, sizeofcmds + len(cmd))
    return bytes(out)


def patch_macho(path):
    data = open(path, "rb").read()
    magic = struct.unpack_from(">I", data, 0)[0]
    if magic in (FAT_MAGIC, FAT_MAGIC_64):
        nfat = struct.unpack_from(">I", data, 4)[0]
        hdr, out = 8, bytearray(data)
        for _ in range(nfat):
            cputype, cpusub, offset, size, algn = struct.unpack_from(">5I", data, hdr)
            hdr += 20
            if cputype != CPU_TYPE_ARM64: continue
            sl = data[offset:offset + size]
            new = patch_slice(sl)
            if new and len(new) == len(sl): out[offset:offset + size] = new
        open(path, "wb").write(bytes(out))
        return True
    new = patch_slice(data)
    if not new: return False
    open(path, "wb").write(new)
    return True


def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    ipa, dylib = sys.argv[1], sys.argv[2]
    outname = os.path.splitext(os.path.basename(ipa))[0] + "_GustavoPanel.ipa"
    tmp = tempfile.mkdtemp()
    with zipfile.ZipFile(ipa) as z: z.extractall(tmp)
    payload = os.path.join(tmp, "Payload")
    apps = [d for d in os.listdir(payload) if d.endswith(".app")]
    if not apps: raise SystemExit("Payload sem .app")
    app = os.path.join(payload, apps[0])
    exe = plistlib.loads(open(os.path.join(app, "Info.plist"), "rb").read())["CFBundleExecutable"]
    print("[*] app:", apps[0], "bin:", exe)
    shutil.copy(dylib, os.path.join(app, "GustavoPanel.dylib"))
    patch_macho(os.path.join(app, exe))
    print("[*] dylib injetada")
    cs = os.path.join(app, "_CodeSignature")
    if os.path.isdir(cs): shutil.rmtree(cs)
    outpath = os.path.join(os.getcwd(), outname)
    with zipfile.ZipFile(outpath, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(tmp):
            for f in files:
                full = os.path.join(root, f)
                z.write(full, os.path.relpath(full, tmp))
    shutil.rmtree(tmp)
    print("[+] pronto:", outpath)


if __name__ == "__main__":
    main()
